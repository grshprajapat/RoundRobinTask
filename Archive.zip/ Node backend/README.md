api to create team member
http://localhost:3000/api/team-members   // POST
request body
{
  "name": "1-MEMBER-TWO",
  "teamId": 1
}


api to create teams // // POST
http://localhost:3000/api/teams
request body
{
  "name": "TEAM FIVE"
}

api to carete the task and assign

http://localhost:3000/api/tasks  // POST

{
  "description": "HEllo My K",
  "teamId": 1
}
